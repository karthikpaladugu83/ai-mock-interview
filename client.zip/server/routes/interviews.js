import express from 'express';
import Interview from '../models/Interview.js';
import auth from '../middleware/auth.js';
import { generateQuestions, generateFeedback } from '../services/gemini.js';

const router = express.Router();

// Helper to get user ID from request
const getUserId = (req) => req.userId || req.body.clerkUserId || req.query.clerkUserId;

// GET /api/interviews - Get all interviews for user
router.get('/', auth, async (req, res, next) => {
  try {
    const userId = getUserId(req);
    if (!userId) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    const interviews = await Interview.find({ clerkUserId: userId })
      .select('role type status score duration createdAt')
      .sort({ createdAt: -1 });

    res.json(interviews);
  } catch (error) {
    next(error);
  }
});

// GET /api/interviews/stats - Get interview statistics
router.get('/stats', auth, async (req, res, next) => {
  try {
    const userId = getUserId(req);
    if (!userId) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    const stats = await Interview.aggregate([
      { $match: { clerkUserId: userId } },
      {
        $group: {
          _id: null,
          total: { $sum: 1 },
          completed: { $sum: { $cond: [{ $eq: ['$status', 'completed'] }, 1, 0] } },
          averageScore: { $avg: '$score' },
        },
      },
    ]);

    res.json(stats[0] || { total: 0, completed: 0, averageScore: 0 });
  } catch (error) {
    next(error);
  }
});

// POST /api/interviews - Create new interview
router.post('/', auth, async (req, res, next) => {
  try {
    const userId = getUserId(req);
    if (!userId) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    const { role, type, experience, jobDescription, focusArea, questionCount } = req.body;

    if (!role || !type || !experience) {
      return res.status(400).json({ error: 'Role, type, and experience are required' });
    }

    const interview = new Interview({
      clerkUserId: userId,
      role,
      type,
      experience,
      jobDescription,
      focusArea,
      questionCount: questionCount || 5,
      status: 'pending',
    });

    await interview.save();
    res.status(201).json(interview);
  } catch (error) {
    next(error);
  }
});

// GET /api/interviews/:id - Get single interview
router.get('/:id', auth, async (req, res, next) => {
  try {
    const userId = getUserId(req);
    const interview = await Interview.findOne({ _id: req.params.id, clerkUserId: userId });

    if (!interview) {
      return res.status(404).json({ error: 'Interview not found' });
    }

    res.json(interview);
  } catch (error) {
    next(error);
  }
});

// GET /api/interviews/:id/questions - Get interview questions
router.get('/:id/questions', auth, async (req, res, next) => {
  try {
    const userId = getUserId(req);
    const interview = await Interview.findOne({ _id: req.params.id, clerkUserId: userId });

    if (!interview) {
      return res.status(404).json({ error: 'Interview not found' });
    }

    res.json(interview.questions.sort((a, b) => a.order - b.order));
  } catch (error) {
    next(error);
  }
});

// POST /api/interviews/:id/generate - Generate AI questions
router.post('/:id/generate', auth, async (req, res, next) => {
  try {
    const userId = getUserId(req);
    const interview = await Interview.findOne({ _id: req.params.id, clerkUserId: userId });

    if (!interview) {
      return res.status(404).json({ error: 'Interview not found' });
    }

    if (interview.questions.length > 0) {
      return res.json(interview.questions);
    }

    // Generate questions using Gemini
    const questions = await generateQuestions(
      interview.role,
      interview.type,
      interview.experience,
      interview.jobDescription,
      interview.focusArea,
      interview.questionCount
    );

    interview.questions = questions;
    interview.status = 'in_progress';
    await interview.save();

    res.json(questions);
  } catch (error) {
    next(error);
  }
});

// POST /api/interviews/:id/submit - Submit interview answers
router.post('/:id/submit', auth, async (req, res, next) => {
  try {
    const userId = getUserId(req);
    const interview = await Interview.findOne({ _id: req.params.id, clerkUserId: userId });

    if (!interview) {
      return res.status(404).json({ error: 'Interview not found' });
    }

    const { answers, questions } = req.body;

    // Save answers
    interview.answers = answers.map((answer, index) => ({
      questionId: interview.questions[index]?._id,
      question: answer.question,
      answer: answer.answer,
    }));

    // Generate feedback using Gemini
    const feedback = await generateFeedback(interview.questions, interview.answers);

    // Update interview with feedback
    interview.feedback = {
      strengths: feedback.strengths || [],
      improvements: feedback.improvements || [],
      technicalScore: feedback.technicalScore || 0,
      communicationScore: feedback.communicationScore || 0,
      confidenceScore: feedback.confidenceScore || 0,
      relevanceScore: feedback.relevanceScore || 0,
      depthScore: feedback.depthScore || 0,
      overallFeedback: feedback.overallFeedback || '',
    };

    // Update answer-level feedback
    if (feedback.questionFeedback) {
      interview.answers = interview.answers.map((answer, index) => ({
        ...answer.toObject(),
        score: feedback.questionFeedback[index]?.score || 0,
        feedback: feedback.questionFeedback[index]?.feedback || '',
        tips: feedback.questionFeedback[index]?.tips || '',
      }));
    }

    interview.score = feedback.score || 0;
    interview.duration = interview.questionCount * 2; // Estimated duration in minutes
    interview.status = 'completed';
    interview.completedAt = new Date();

    await interview.save();

    res.json({ success: true, score: interview.score });
  } catch (error) {
    next(error);
  }
});

// GET /api/interviews/:id/feedback - Get interview feedback
router.get('/:id/feedback', auth, async (req, res, next) => {
  try {
    const userId = getUserId(req);
    const interview = await Interview.findOne({ _id: req.params.id, clerkUserId: userId });

    if (!interview) {
      return res.status(404).json({ error: 'Interview not found' });
    }

    if (interview.status !== 'completed') {
      return res.status(400).json({ error: 'Interview not completed yet' });
    }

    res.json({
      score: interview.score,
      role: interview.role,
      type: interview.type,
      date: interview.completedAt || interview.updatedAt,
      answered: interview.answers.filter(a => a.answer).length,
      total: interview.questions.length,
      questionFeedback: interview.answers.map(a => ({
        question: a.question,
        answer: a.answer,
        score: a.score,
        feedback: a.feedback,
        tips: a.tips,
      })),
      strengths: interview.feedback?.strengths || [],
      improvements: interview.feedback?.improvements || [],
      technicalScore: interview.feedback?.technicalScore || 0,
      communicationScore: interview.feedback?.communicationScore || 0,
      confidenceScore: interview.feedback?.confidenceScore || 0,
      relevanceScore: interview.feedback?.relevanceScore || 0,
      depthScore: interview.feedback?.depthScore || 0,
      overallFeedback: interview.feedback?.overallFeedback || '',
    });
  } catch (error) {
    next(error);
  }
});

// DELETE /api/interviews/:id - Delete interview
router.delete('/:id', auth, async (req, res, next) => {
  try {
    const userId = getUserId(req);
    const interview = await Interview.findOneAndDelete({ _id: req.params.id, clerkUserId: userId });

    if (!interview) {
      return res.status(404).json({ error: 'Interview not found' });
    }

    res.json({ message: 'Interview deleted successfully' });
  } catch (error) {
    next(error);
  }
});

export default router;

