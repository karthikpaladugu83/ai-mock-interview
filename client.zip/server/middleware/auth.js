import { getAuth } from '@clerk/express';

const authenticateUser = (req, res, next) => {
  try {
    const { isAuthenticated, userId } = getAuth(req);

    if (!isAuthenticated) {
      return res.status(401).json({
        error: 'Unauthorized',
        code: 'UNAUTHORIZED',
      });
    }

    req.userId = userId;
    next();
  } catch (error) {
    console.error('Authentication Error:', error);

    return res.status(401).json({
      error: 'Authentication failed',
      code: 'AUTH_FAILED',
    });
  }
};

export default authenticateUser;